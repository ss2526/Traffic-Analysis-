<img width="1595" alt="Screenshot 2024-09-27 at 7 40 28 PM" src="https://github.com/user-attachments/assets/9b56689e-f7ae-4df8-8111-14000ca6099f">
